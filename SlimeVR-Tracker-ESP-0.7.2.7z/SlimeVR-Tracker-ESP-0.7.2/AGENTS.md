# SlimeVR Tracker ESP 固件项目

## 项目概述

SlimeVR Tracker ESP 是一个用于 ESP8266/ESP32 微控制器的固件项目，支持多种 IMU 传感器，使其作为 VR 追踪器使用。该固件需要配合 [SlimeVR Server](https://github.com/SlimeVR/SlimeVR-Server) 工作，用于解析姿态数据并与 SteamVR 集成。

### 主要技术栈
- **开发框架**: Arduino (通过 PlatformIO 构建)
- **目标平台**: ESP8266 / ESP32 系列芯片
- **通信协议**: WiFi (UDP) 与 SlimeVR Server 通信
- **支持的 IMU 传感器**:
  - BNO085/BNO086 (推荐，支持 ARVR 稳定化)
  - BNO080
  - MPU-6050/MPU-6500
  - BNO055
  - MPU-9250 (实验性)
  - BMI160 (实验性)
  - ICM-20948 (实验性)
  - BMI270, ICM-42688, LSM6DS 系列 (实验性，SoftFusion)

### 架构模块
- **传感器管理** (`src/sensors/`): IMU 传感器驱动和融合算法
- **网络通信** (`src/network/`): WiFi 连接和数据包处理
- **配置管理** (`src/configuration/`): 设备配置持久化
- **状态管理** (`src/status/`): LED 指示和状态追踪
- **运动处理** (`src/motionprocessing/`): 陀螺仪温度校准和休息检测

## 构建和运行

### 环境要求
- PlatformIO (推荐通过 VS Code 扩展安装)
- Python 3.x (用于预处理器脚本)
- Git

### 构建命令

```bash
# 构建默认环境 (BOARD_WEMOSD1MINI)
pio run

# 构建特定板型
pio run -e BOARD_WROOM32
pio run -e BOARD_ESP32S3_SUPERMINI

# 上传固件
pio run -t upload -e BOARD_WEMOSD1MINI

# 串口监视器
pio device monitor
```

### 主要构建环境
| 环境名称 | 平台 | 说明 |
|---------|------|------|
| `BOARD_WEMOSD1MINI` | ESP8266 | 默认环境 |
| `BOARD_NODEMCU` | ESP8266 | NodeMCU 板 |
| `BOARD_WROOM32` | ESP32 | 标准 ESP32 开发板 |
| `BOARD_ESP32S3_SUPERMINI` | ESP32-S3 | ESP32-S3 SuperMini |
| `BOARD_LOLIN_C3_MINI` | ESP32-C3 | LOLIN C3 Mini |
| `BOARD_SLIMEVR` | ESP8266 | 官方 SlimeVR 追踪器 |
| `BOARD_SLIMEVR_V1_2` | ESP8266 | SlimeVR v1.2 版本 |

### CI 构建
```bash
# 构建所有目标
python ci/build.py
```

## 配置说明

### 固件配置文件

1. **`defines.h`** - 主配置文件
   - 设置 IMU 类型 (`IMU`, `SECOND_IMU`)
   - 设置板型 (`BOARD`)
   - 配置传感器旋转偏移 (`IMU_ROTATION`)
   - 电池监控选项

2. **`debug.h`** - 调试选项
   - 日志级别设置
   - 采样率配置
   - 省电模式设置

3. **`board-defaults.json`** - 板级默认配置
   - 传感器引脚定义
   - LED 配置
   - 电池监控参数

### 添加新板型
1. 在 `board-defaults.json` 中添加板型配置
2. 在 `platformio.ini` 中添加构建环境
3. 在 `src/consts.h` 中添加板型常量

## 开发规范

### 代码风格
- **缩进**: Tab (4 空格宽度)
- **行宽**: 最大 88 字符
- **编码**: UTF-8
- **换行**: LF
- 详见 `.clang-format` 和 `.editorconfig`

### 许可证
项目采用双许可证:
- MIT License
- Apache License 2.0

所有贡献代码需兼容上述许可证，不接受 GPL/LGPL 等传染性许可证的代码。

### 提交贡献
1. Fork 仓库
2. 创建功能分支
3. 提交 Pull Request
4. 确保 CI 构建通过

### 添加第三方依赖
- 检查依赖许可证是否为 MIT/Apache/BSD
- 如需修改依赖源码，应 Fork 到 SlimeVR 组织
- 在 `platformio.ini` 的 `lib_deps` 中添加依赖

## 项目结构

```
SlimeVR-Tracker-ESP/
├── src/                    # 主源代码
│   ├── main.cpp           # 入口文件
│   ├── defines.h          # 主配置
│   ├── debug.h            # 调试选项
│   ├── consts.h           # 常量定义
│   ├── sensors/           # 传感器驱动
│   ├── network/           # 网络通信
│   ├── configuration/     # 配置管理
│   ├── status/            # 状态管理
│   └── boards/            # 板级定义
├── lib/                   # 本地库
│   ├── bno055_adafruit/   # BNO055 驱动
│   ├── bno080/            # BNO080 驱动
│   ├── mpu6050/           # MPU6050 驱动
│   ├── ICM20948/          # ICM20948 驱动
│   └── vqf/               # VQF 融合算法
├── Ku/                    # 第三方库 (PlatformIO 依赖)
├── boards/                # 自定义板定义
├── scripts/               # 构建脚本
│   └── preprocessor.py    # PlatformIO 预处理器
├── ci/                    # CI 脚本
│   └── build.py           # 构建脚本
├── test/                  # 单元测试
├── platformio.ini         # PlatformIO 配置
└── board-defaults.json    # 板级默认配置
```

## 常见任务

### 修改传感器配置
编辑 `defines.h` 或通过环境变量覆盖:
```bash
# 设置 IMU 类型
-DIMU=IMU_BNO085

# 设置 WiFi 凭据
-DWIFI_CREDS_SSID='"MyWiFi"'
-DWIFI_CREDS_PASSWD='"MyPassword"'
```

### 启用 OTA 更新
在 `platformio.ini` 中取消注释:
```ini
upload_protocol = espota
upload_port = 192.168.1.49
upload_flags = --auth=SlimeVR-OTA
```

### 启用调试输出
在 `debug.h` 中设置:
```c
#define serialDebug true
#define LOG_LEVEL LOG_LEVEL_TRACE
```

## 相关链接

- [官方文档](https://docs.slimevr.dev/)
- [SlimeVR Server](https://github.com/SlimeVR/SlimeVR-Server)
- [Discord 社区](https://discord.gg/SlimeVR)
- [配置指南](https://docs.slimevr.dev/firmware/configuring-project.html)
